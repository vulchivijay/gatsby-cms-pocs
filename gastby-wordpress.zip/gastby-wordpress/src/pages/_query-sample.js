// query MyQuery($slug: String! $previousPostId: String $nextPostId: String)
// {
//   allWpPost(filter: { slug: { eq: $slug } }) {
//     nodes {
//       title
//     }
//   }
//   previous: allWpPost(filter: {id: {eq: $previousPostId} }) {
//     nodes {
//       slug
//       title
//     }
//   }
//   next: allWpPost(filter: {id: {eq: $nextPostId} }) {
//     nodes {
//       slug
//       title
//     }
//   }
// }


// {
//   "slug": "how-should-enterprises-execute-cross-browser-testing",
//   "previousPostId": "cG9zdDox",
//   "nextPostId": "cG9zdDoyOA=="
// }