import React from "react"
import Layout from "../components/layout"
import Seo from "../components/seo"

export default function Pricing () {
  return (
    <Layout>
      <Seo title="Pricing" />
      <div className="container">
        <h1>Pricing page</h1>
      </div>
    </Layout>
  )
}