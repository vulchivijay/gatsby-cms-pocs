import React from "react"
import { graphql } from "gatsby"
import Layout from "../components/layout"
import Seo from "../components/seo"

export default function Home({ data }) {
  const pageData = data.allWpPage.nodes[0];
  
  return (
    <Layout>
      <Seo title="home" />
      <div className="container">
        <div dangerouslySetInnerHTML={{ __html: pageData.content }} />
      </div>
    </Layout>
  )
}

export const HomeQuery = graphql`
  query {
    allWpPage(filter: {title: {eq: "Home page"}}) {
      nodes {
        title
        slug
        content
      }
    }
  }
`