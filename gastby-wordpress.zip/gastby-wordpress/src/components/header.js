import { Link } from "gatsby"
import * as React from "react"

const Header = () => {
  return (
    <header>
      <div className="container flex space-between">
        <Link to="/" className="logo">Logo CompanyName</Link>
        <nav>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/pricing">Pricing</Link>
          <Link to="/blog">Blog</Link>
        </nav>
      </div>
    </header>
  )
}

export default Header