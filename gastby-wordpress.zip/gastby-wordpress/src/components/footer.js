import * as React from "react"

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <p>&copy; 2021</p>
      </div>
    </footer>
  )
}

export default Footer