import React from "react"
import { Link, graphql } from "gatsby"
import { GatsbyImage, getImage } from "gatsby-plugin-image"
import Layout from "../components/layout"
import Seo from "../components/seo"

export default function Home({ data, pageContext }) {
  const { currentPage, isFirstPage, isLastPage, totalBlogs } = pageContext
  const nextPage = `/blog/${String(currentPage + 1)}`
  const prevPage = currentPage - 1 === 1 ? `/blog` : `/blog/${String(currentPage -1)}`

  return (
    <Layout>
      <Seo title="Blog" />
      <div className="container-small blog-page">
        <h4 className="post-title">All Posts ({data.allWpPost.totalCount}) </h4>
        <div className="flex">
          {data.allWpPost.nodes.map((node) => (
            <div key={node.slug} className="card blog-page-post">
              <GatsbyImage
                image={getImage(node.featuredImage.node.localFile)}
                alt={node.featuredImage.node.altText}
              />
              <h2><a href={'http://localhost:8000/blog/' + node.slug} title={node.slug}>{node.title}</a></h2>
              {/* <div dangerouslySetInnerHTML={{ __html: node.excerpt }} /> */}
              <div className="flex space-between p-1">
                <span>{node.author.node.name}</span>
                <a href={'http://localhost:8000/blog/' + node.slug} title={node.slug}>Read more... </a>
              </div>
            </div>
          ))}
        </div>
        {/* navigation */}
        <nav className="blog-post-nav">
            <ul
              style={{
                display: `flex`,
                flexWrap: `wrap`,
                justifyContent: `space-between`,
                listStyle: `none`,
                padding: 0,
              }}
            >
              <li>
                {!isFirstPage && (
                  <Link to={prevPage} rel="prev">← Previous</Link>
                )}
              </li>
              <li>
                {
                  Array.from({ length: totalBlogs }, (_, index) => (
                    <Link key={index} to={`/blog/${index === 0 ? '' : index + 1}`}>
                      {index + 1}
                    </Link>
                  ))
                }
              </li>
              <li>
                {!isLastPage && (
                  <Link to={nextPage} rel="next">Next →</Link>
                )}
              </li>
            </ul>
        </nav>
      </div>
    </Layout>
  )
}

export const pageQuery = graphql`
  query ($skip: Int!, $limit: Int!) {
    allWpPost(sort: { fields: [date], order: DESC }, skip: $skip, limit: $limit) {
      totalCount
      nodes {
        title
        excerpt
        slug
        featuredImage {
          node {
            altText
            localFile {
              childImageSharp {
                gatsbyImageData
              }
            }
          }
        }
        author {
          node {
            name
          }
        }
      }
    }
  }
`