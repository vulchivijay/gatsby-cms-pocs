import React from "react"
import { graphql } from "gatsby"
import { GatsbyImage, getImage } from "gatsby-plugin-image"
import Layout from "../components/layout"
import Seo from "../components/seo"

export default function BlogPost({ data }) {
  const post = data.allWpPost.nodes[0]
  const previous = data.previous.nodes[0]
  const next = data.next.nodes[0]

  return (
    <Layout>
      <Seo title="Post" />
      <div className="container-small">
        <div className="post-content ptb-3">
          <GatsbyImage
            image={getImage(post.featuredImage.node.localFile)}
            alt={post.featuredImage.node.altText}
          />
          <h1>{post.title}</h1>
          <div dangerouslySetInnerHTML={{ __html: post.content }} />
          {/* navigation */}
          <nav className="blog-post-nav">
            <ul
              style={{
                display: `flex`,
                flexWrap: `wrap`,
                justifyContent: `space-between`,
                listStyle: `none`,
                padding: 0,
              }}
            >
              <li>
                {previous && (
                  <a href={`http://localhost:8000/blog/` + previous.slug} rel="prev" title={previous.slug}>
                    ← Previous {/* ← {previous.title} */}
                  </a>
                )}
              </li>
              <li>
                {next && (
                  <a href={`http://localhost:8000/blog/` + next.slug} rel="next" title={next.slug}>
                    {/* {next.title} → */} Next →
                  </a>
                )}
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </Layout>
  )
}

export const query = graphql`
  query($slug: String! $previousPostId: String $nextPostId: String) {
    allWpPost(filter: { slug: { eq: $slug } }) {
      nodes {
        title
        content
        featuredImage {
          node {
            altText
            localFile {
              childImageSharp {
                gatsbyImageData
              }
            }
          }
        }
      }
    }
    previous: allWpPost(filter: {id: {eq: $previousPostId} }) {
      nodes {
        slug
        title
      }
    }
    next: allWpPost(filter: {id: {eq: $nextPostId} }) {
      nodes {
        slug
        title
      }
    }
  }
`