const path = require(`path`)

exports.createPages = ({ graphql, actions }) => {
  const { createPage } = actions
  return graphql(`
    {
      allWpPost(sort: { fields: [date] }) {
        nodes {
          title
          excerpt
          content
          slug
          id
        }
      }
    }
  `).then((result) => {
    const posts = result.data.allWpPost.nodes

    posts.forEach((node, index) => {
      const previousPostId = index === 0 ? null : posts[index - 1].id
      const nextPostId = index === posts.length - 1 ? null : posts[index + 1].id

      createPage({
        path: '/blog/' + node.slug,
        component: path.resolve(`./src/templates/blog-post-template.js`),
        context: {
          // This is the $slug variable
          // passed to blog-post.js
          slug: node.slug,
          previousPostId,
          nextPostId,
        },
      })
    })

    const blogsPerPage = 1
    const totalBlogs = Math.ceil(posts.length / blogsPerPage)

    Array.from({ length: totalBlogs }).forEach((_, index) => {
      const currentPage = index + 1
      const isFirstPage = index === 0
      const isLastPage = currentPage === totalBlogs
      
      createPage({
        path: isFirstPage ? '/blog' : `/blog/${currentPage}`,
        component: require.resolve("./src/templates/blog-template.js"),
        context: {
          limit: blogsPerPage,
          skip: index * blogsPerPage,
          isFirstPage,
          isLastPage,
          currentPage,
          totalBlogs,
        }
      })
    })
  })
}